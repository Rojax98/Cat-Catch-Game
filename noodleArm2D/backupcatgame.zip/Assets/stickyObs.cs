﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class stickyObs : MonoBehaviour {


    Rigidbody2D otherbody;

    bool hit;

    public GameObject arms;
    public GameObject cameraMain;

	// Use this for initialization
	void Start () {

        arms = GameObject.FindGameObjectWithTag("arms");
        cameraMain = GameObject.FindGameObjectWithTag("MainCamera");

	}

    // Update is called once per frame
    void FixedUpdate()
    {
        if (hit == true)
        {

            Vector3 viewPos = Camera.main.WorldToViewportPoint(transform.position);

            if (viewPos.x < 0 || viewPos.x > 1)
            {

                cameraMain.GetComponent<zoom>().zoomOut = true;
            }

            if (viewPos.y < 0 || viewPos.y > 1)
            {

                cameraMain.GetComponent<zoom>().zoomOut = true;
            }
        }

    }

    private void OnTriggerEnter2D(Collider2D collision)
    {

        // print("hit");
        if (collision.gameObject.tag == "lArm" && hit == false)
        {           
            Destroy(GetComponent<Rigidbody2D>());           
            transform.SetParent(collision.transform);
            tag = "lArm";
            arms.GetComponent<Balance>().leftOffset += 0.5f;
            GetComponent<CircleCollider2D>().isTrigger = true;
            hit = true;

        }


        if (collision.gameObject.tag == "rArm" && hit == false)
        {
            Destroy(GetComponent<Rigidbody2D>());
            transform.SetParent(collision.transform);
            tag = "rArm";
            arms.GetComponent<Balance>().rightOffset += 0.5f;
            GetComponent<CircleCollider2D>().isTrigger = true;
            hit = true;

        }
    }

   

}
