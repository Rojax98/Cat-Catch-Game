﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class zoom : MonoBehaviour {

    public bool zoomOut;

    float timer;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

        float size = Camera.main.orthographicSize;

        if (zoomOut == true)
        {

            size += 0.025f;

            timer += 1 * Time.deltaTime;

            if(timer > 0.5f)
            {
                zoomOut = false;
                timer = 0;
            }
        }

        Camera.main.orthographicSize = size;

        //Debug.Log(Camera.main.fieldOfView = fov);



    }
}
