﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class joystickmoveRight : MonoBehaviour {

    Rigidbody2D rb;

    public Transform centre;

    Vector3 lastPos;

    // Use this for initialization
    void Start()
    {

    }

    // Update is called once per frame
    void FixedUpdate()
    {

        rb = GetComponent<Rigidbody2D>();

       // Debug.Log(Input.GetAxis("RightTrigger"));

        var distance = Vector3.Distance(centre.position, transform.position);

        //print(distance);

        //if (Input.GetAxis("RightTrigger") > 0.1f)
        //{

            if (RightStickPos().sqrMagnitude > 0.25f)
            {




                transform.position += (RightStickPos());

            }

            if (RightStickPos().sqrMagnitude < 0.25f)
            {
          
            }
        //}

        if (Input.GetAxis("RightTrigger") <= 0.1f)
        {
     
        }


        if (Input.GetMouseButton(1))
        {

            transform.position = Camera.main.ScreenToWorldPoint(Input.mousePosition);

        }

        if (Vector3.Distance(centre.position, transform.position) > 9f)
        {


            transform.position = centre.position + (transform.position - centre.position).normalized * distance;


        }



       // Debug.Log(centre.position + (transform.position - centre.position).normalized * distance);

    }



    Vector3 RightStickPos()
    {


        return new Vector3(Input.GetAxisRaw("RightStickH"), Input.GetAxisRaw("RightStickV"), 0);

    }


}