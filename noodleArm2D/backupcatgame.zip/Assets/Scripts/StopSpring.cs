﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StopSpring : MonoBehaviour {

    HingeJoint2D hJ;


	// Use this for initialization
	void Start () {


        hJ = GetComponent<HingeJoint2D>();


    }
	
	// Update is called once per frame
	void Update () {





        ///var currentR = new Vector3(0, 0, 0);

       // var rotation = Quaternion.Euler(currentR); 

        //print(rotation);    

        //hJ.transform.rotation = 
	}
}
