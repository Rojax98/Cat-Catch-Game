﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class joystickmoveLeft : MonoBehaviour {

    public Transform centre;

    bool resetPos;

    Vector3 lastPos;

	// Use this for initialization
	void Start () {
		
	}

    // Update is called once per frame
    void Update()
    {

        var distance = Vector3.Distance(centre.position, transform.position);

        //if (Input.GetAxis("LeftTrigger") > 0.1f)
       // {

            if (LeftStickPos().sqrMagnitude > 0.25f)
            {

                transform.position += (LeftStickPos());

            }
        //}

            if (Input.GetMouseButton(0))
            {

                transform.position = Camera.main.ScreenToWorldPoint(Input.mousePosition);

            }

            if (Vector3.Distance(centre.position, transform.position) > 9f)
            {

                transform.position = centre.position + (transform.position - centre.position).normalized * distance;
            }
        
        
    }



    Vector3 LeftStickPos()
    {


        return new Vector3(Input.GetAxisRaw("LeftStickH"), Input.GetAxisRaw("LeftStickV"), 0);

    }
}
