﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Balance : MonoBehaviour {

    public GameObject centre;
    public GameObject lArm;
    public GameObject rArm;

    public float leftWeight;
    public float rightWeight;

    public float balance;

    public float rightOffset =0;
    public float leftOffset =0;

    float offset;

    float timer;

	// Use this for initialization
	void Start () {

        offset = Random.Range(-5,5);

	}

    // Update is called once per frame
    void Update() {

        timer += 1 * Time.deltaTime;

        if (timer > 2)
        {
            offset = Random.Range(-5, 5);
            timer = 0;

        }


        leftWeight = Vector2.Distance(lArm.transform.position, centre.transform.position) + leftOffset;
        rightWeight = Vector2.Distance(rArm.transform.position, centre.transform.position) + rightOffset;

        balance = (leftWeight - rightWeight) + offset;

        transform.Rotate(0, 0, balance/10);

    }
}
