﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ballspawn : MonoBehaviour {


    public GameObject Obstacle;

    float timer;

	// Use this for initialization
	void Start () {


		
	}
	
	// Update is called once per frame
	void Update () {

        timer += 1 * Time.deltaTime;

        if(timer > 2)
        {
            Instantiate(Obstacle, new Vector3(Random.Range(-10, 10), transform.position.y, 0), Quaternion.identity);

            timer = 0;

        }


        Vector3 viewPos = Camera.main.WorldToViewportPoint(transform.position);

        print(viewPos.y);

        if (viewPos.y < 1.5)
        {
            transform.position += new Vector3(0,1,0);
            
        }

    }

    

  
}
